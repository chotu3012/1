 import java.util.*;
 abstract class twodShape{
   abstract  double getArea(double a);
     
 }
  abstract class threedShape{
  abstract  double getArea(double a);
    abstract  double getvol(double a);
 }
 class square extends twodShape{
      double getArea(double a){
          return a*a;
      }
 }
 class  circle extends twodShape{
      double getArea(double a){
          return 3.14*a*a;
      }
 }
 class  cube extends threedShape{
      double getvol(double a){
          return a*a*a;
      }
      double getArea(double a){
          return 6*a*a;
      }
 }
 class  sphere extends threedShape{
      double getvol(double a){
          return (double)(4/3)*a*a*a;
      }
      double getArea(double a){
          return 4*3.14*a*a*a;
      }
 }
 public class shape{
   public static void main(String args[]){
         Scanner sc=new Scanner(System.in);
         System.out.println("ENTER the side of a square");
         double x=sc.nextDouble();
         square s=new square();
         System.out.println("Area is "+s.getArea(x));
         System.out.println("ENTER the radius of a circle");
         double y=sc.nextDouble();
         circle c=new circle();
         System.out.println("Area is "+c.getArea(y));
         System.out.println("ENTER the side of a cube");
         double z=sc.nextDouble();
         cube cu=new cube();
         System.out.println("vol is"+cu.getvol(z));
         System.out.println("Area is "+Math.round(cu.getArea(x)));
         System.out.println("ENTER the radius of a sphere");
         double w=sc.nextDouble();
         sphere sp=new sphere();
         System.out.println("vol is"+sp.getvol(w));
         System.out.println("Area is "+sp.getArea(x));
   }
   

}
