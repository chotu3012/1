import java.util.*;
interface vech{
  String getCompany();
  String getModel();
  String getType();
  double getConsumption(int d);
}
class twowheeler implements vech{
   String company;
   String model;
   String type;
   public twowheeler(String co,String mo,String ty){
       company=co;
       model=mo;
       type=ty;
   }
   public String getCompany(){
        return company;
   }
   public String getModel(){
        return model;
   }
   public String getType(){
        return type;
   }
  public double getConsumption(int d){
      if(type.equals("petrol")){
          return (double)d/(double)62;
      }
      else if(type.equals("CNG")){
          return (double)d/(double)72;
      }
      else if(type.equals("Diesel")){
          return (double)d/(double)82;
      }
      return -1;
   }  
}
class fourwheeler implements vech{
   String company;
   String model;
   String type;
   public fourwheeler(String co,String mo,String ty){
       company=co;
       model=mo;
       type=ty;
   }
   public String getCompany(){
        return company;
   }
   public String getModel(){
        return model;
   }
   public String getType(){
        return type;
   }
  public double getConsumption(int d){
      if(type.equals("petrol")){
          return (double)d/(double)14;
      }
      else if(type.equals("CNG")){
          return (double)d/(double)18;
      }
      else if(type.equals("Diesel")){
          return (double)d/(double)22;
      }
      return -1;
   }  
}

public class vechile{
    public static void main(String args[]){
          Scanner sc=new Scanner(System.in);
         int x=0;
         while(x!=-1){
          System.out.println("mention type of vechile");
         x=sc.nextInt();
         switch(x){
            case 2:
              twowheeler tw=new  twowheeler("honda","model-2","petrol");
              System.out.println("company name is"+tw.getCompany());
              System.out.println("mention the distance vechile travelled");
              int d=sc.nextInt();
             System.out.println("fuel consumption of vechile is"+tw.getConsumption(d));
             break;
            case 4:
               fourwheeler fw=new  fourwheeler("tata","model-x","Diesel");
              System.out.println("mention the distance vechile travelled");
              System.out.println("company name is"+fw.getCompany());
              int h=sc.nextInt();
              System.out.println("fuel consumption of vechile is"+fw.getConsumption(h)+"litres");
             break;
         }
       }
    
         
    }
}
