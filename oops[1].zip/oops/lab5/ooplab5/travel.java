import java.util.*;
interface fare{
double getfare(String ttype, double  distance);
String[] getAmenity(String type);
}
class Bus implements fare{
public double getfare(String ttype,double distance){
  if(ttype.equals("A/C")){
   return distance*250;
  }
  else if(ttype.equals("NonA/C")){
   return distance*50;
  }
  else if(ttype.equals("sleeper")){
   return distance*150;
  }
  return 0;
}
public String[] getAmenity(String type){
  if(type.equals("A/C")){
    String arr[]={"Dinner","Snacks"};
    return  arr;
  }
  else if(type.equals("NonA/C")){
    String arr[]={"Snacks"};
    return  arr;
  }
  else if(type.equals("sleeper")){
    String arr[]={"Snacks","T.v facility"};
    return  arr;
  }
  else{
    String arr[]={"choose prefer class"};
    return  arr;
  }
}

}
class train implements fare{
  public double getfare(String ttype,double distance){
    if(ttype.equals("A/C")){
     return distance*350;
    }
    else if(ttype.equals("general")){
     return distance*250;
    }
    else if(ttype.equals("sleeper")){
     return distance*150;
    }
    return 0;
  }
  public String[] getAmenity(String type){
    if(type.equals("A/C")){
      String arr[]={"Dinner","Snacks"};
      return  arr;
    }
    else if(type.equals("general")){
      String arr[]={"Sanity"};
      return  arr;
    }
    else if(type.equals("sleeper")){
      String arr[]={"Snacks","sleeper bed"};
      return  arr;
    }
    else{
      String arr[]={"choose prefer class"};
      return  arr;
    }
  }
  
  }
  class flight implements fare{

    public double getfare(String ttype,double  distance){
      if(ttype.equals("Economy")){
       return distance*500;
      }
      else if(ttype.equals("Business")){
       return distance*1000;
      }
      return 0;
    }
    public String[] getAmenity(String type){
      if(type.equals("Economy")){
        String arr[]={"Drinks,Dinner","Snacks","Music "};
        return  arr;
      }
      else if(type.equals("Business")){
        String arr[]={"Snacks","Dinner"};
        return  arr;
      }

      else{
        String arr[]={"choose prefer class"};
        return  arr;
      }
    }
    
    }

class travel{    public static void main(String[] args){
       Scanner sc=new Scanner(System.in);
       System.out.println("Ente the medium you want to travel in");
       String s=sc.next();
       System.out.println("Enter the distance of  your destination:");
       double i=sc.nextDouble();
       System.out.println("Enter the classtype:");
       String cl=sc.next();
      
       if(s.equals("Bus")){
        Bus b=new Bus();
        System.out.println("fare is"+b.getfare(cl,i));
          System.out.println("Amenities are:");
        String arr[]=b.getAmenity(cl);
        for(int j=0;j<arr.length;j++){
          System.out.println(arr[j]);
        }

       }
       else if(s.equals("train")){
        train t=new train();
        System.out.println("fare is"+t.getfare(cl,i));
          System.out.println("Amenities are:");
        String arr[]=t.getAmenity(cl);
        for(int j=0;j<arr.length;j++){
          System.out.println(arr[j]);
        }
       }
       else if(s.equals("flight")){
        flight f=new flight();
        System.out.println("fare is"+f.getfare(cl,i));
        System.out.println("Amenities are:");
        String arr[]=f.getAmenity(cl);
        for(int j=0;j<arr.length;j++){
          System.out.println(arr[j]);
        
       }
      }
       else{
          System.out.println("You entered an incorrect data");
       }

    }
  }
