import java.util.*;
abstract class employe{
abstract double getAmount(int d,int td);
}
class weeklyemp extends employe{
    int wage=60;
    double getAmount(int d,int td){
       return d*wage/td;
    }
}
class hourlyemp extends employe{
    int wage=20;
    double getAmount(int h,int th){
       return wage*h/th;
    }
}
public class employee{
   public static void main(String args[]){
       Scanner sc=new Scanner(System.in);
       int x=0;
       while(x!=-1){
          System.out.println("mention type of employee");
         x=sc.nextInt();
         switch(x){
            case 1:
              weeklyemp we=new weeklyemp();
              System.out.println("no.of days you are worked");
              int d=sc.nextInt();
               System.out.println("out of no.of days are ");
             int td=sc.nextInt();
             System.out.println("the amount you will get is"+we.getAmount(d,td));
             break;
            case 2:
              hourlyemp he=new hourlyemp();
              System.out.println("no.of days you are worked");
              int h=sc.nextInt();
               System.out.println("out of no.of days are ");
             int th=sc.nextInt();
             System.out.println("the amount you will get is"+Math.floor(he.getAmount(h,th)));
             break;
         }
       }
   
   }
   
}
