public class account {
     double balance;
}
