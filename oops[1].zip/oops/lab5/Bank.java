import java.util.*;
class sbi implements RBI {
    public void credit(double amount,account a){
        a.balance=a.balance+amount;    
    }
    public void debit(double amount,account a){
        if(a.balance>=amount){
            a.balance=a.balance-amount;
        }
        else{
            System.out.println("Not sufficient Balance");
        }
    }
    public void displaybalance(account a) {
        System.out.println(a.balance);
    }
    public void elgible(account a,String type){
        if(a.balance>50000 && type.equals("govt")){
            System.out.println("You are elgible for personal loan");
        }
        else if(a.balance<50000 && type.equals("pvt")){
            System.out.println("You are elgible for Vechile loan");
        }
        else if(a.balance>100000 && type.equals("govt")){
            System.out.println("You are elgible for Homeloan");
        }
         else{
           System.out.println("You are not elgible for loan"); 
        }
    }
    
}
class hdfc implements RBI {
    public void credit(double amount,account a){
        a.balance=a.balance+amount;    
    }
    public void debit(double amount,account a){
        if(a.balance>=amount){
            a.balance=a.balance-amount;
        }
        else{
            System.out.println("Not sufficient Balance");
        }
    }
    public void displaybalance(account a) {
        System.out.println(a.balance);
    }
    public void elgible(account a,String type){
        if(a.balance>100000 && type.equals("govt")){
            System.out.println("You are elgible for personal loan");
        }
        else if(a.balance<20000 && type.equals("pvt")){
            System.out.println("You are elgible for Vechile loan");
        }
        else if(a.balance>50000 && type.equals("govt")){
            System.out.println("You are elgible for Homeloan");
        }
         else{
           System.out.println("You are not elgible for loan"); 
        }
    }
    
}
class dcb implements RBI {
    public void credit(double amount,account a){
        a.balance=a.balance+amount;    
    }
    public void debit(double amount,account a){
        if(a.balance>=amount){
            a.balance=a.balance-amount;
        }
        else{
            System.out.println("Not sufficient Balance");
        }
    }
    public void displaybalance(account a) {
        System.out.println(a.balance);
    }
    public void elgible(account a,String type){
        if(a.balance>60000 && type.equals("govt")){
            System.out.println("You are elgible for personal loan");
        }
        else if(a.balance<30000 && type.equals("pvt")){
            System.out.println("You are elgible for Vechile loan");
        }
        else if(a.balance>75000 && type.equals("govt")){
            System.out.println("You are elgible for Homeloan");
        }
        else{
           System.out.println("You are not elgible for loan"); 
        }
    }
    
}
public class Bank  {
    public static void main(String args[]){
            Scanner sc=new Scanner(System.in);
          account a=new account();
          int x=0;
          sbi s=new sbi();
          dcb d=new dcb();
          hdfc h=new hdfc();
         System.out.println("Enter your bank:");
         String k=sc.next();
          while(x!=-1){
            System.out.println("Enter your operation to perform");
            String st=sc.next();
            switch(st){
                case "credit":
                  System.out.println("Enter your amount to creadit");
                  double am=sc.nextDouble();
                  if(k.equals("SBI")){
                       s.credit(am,a);
                  }
                  else if(k.equals("hdfc")){
                       h.credit(am,a);
                  }
                   else if(k.equals("dcb")){
                       d.credit(am,a);
                  }
                break;
                case "debit":
                  System.out.println("Enter your amount to debit");
                  double ad=sc.nextDouble();
                  if(k.equals("SBI")){
                       s.debit(ad,a);
                  }
                  else if(k.equals("hdfc")){
                       h.debit(ad,a);
                  }
                   else if(k.equals("dcb")){
                       d.debit(ad,a);
                  }
                 break;
                case "displaybalance":
                  if(k.equals("SBI")){
                       s.displaybalance(a);
                  }
                  else if(k.equals("hdfc")){
                       h.displaybalance(a);
                  }
                   else if(k.equals("dcb")){
                       d.displaybalance(a);
                  }
                break;
                case "loan":
                  System.out.println("Enter your jobtype:");
                  String j=sc.next();
                if(k.equals("SBI")){
                       s.elgible(a,j);
                  }
                  else if(k.equals("hdfc")){
                       h.elgible(a,j);
                  }
                   else if(k.equals("dcb")){
                       d.elgible(a,j);
                  }
                break;
            }
            System.out.println("x:");
            x=sc.nextInt();
          }
        
    }
    
}
