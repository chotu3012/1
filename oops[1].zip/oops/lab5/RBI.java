interface RBI{
    void credit(double amount,account a);
    void debit(double amount,account a);
    void displaybalance(account a);
}