 class A{
    public static void cal(int a){
        System.out.println(a*a);
    }
 }
 class B extends A{
     public static void cal(int a){
        System.out.println(a);
    }
 }
 public class helo {
    public static void main(String[] args){
        A b=new B();
        b.cal(5);

    }
    
}
