import java.util.*;
class account{
    String Bank_name;
    String Branch_name;
    String acct_name;
    int accno;
    double balance;
     String act_adresss;
    public void credit(double amount,account a){
         a.balance = a.balance+amount;
    }
    public void debit(double amount,account a){
         if(amount>a.balance){
            System.out.println("Your account has insufficient balance ");
         }
         else{
            a.balance=a.balance-amount;
         }
    }
    public void getbalance(account a){
          System.out.println("Your balance is"+a.balance);
    }
}
    public class bank{
        public static  boolean check( String arr[],String s){
            for(int i=0;i<arr.length;i++){
                if(arr[i].equals(s)){
                    return true;
                }
            }
            return false;
        }
        public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        //Registered accounts in Nizamabad branch
        String Nizamabad[]={"20432","20413","14320","24454","23521"};
        String Basar[]={"12345","12340","02341","34241","54123"};
        account a=new account();
            System.out.println("Enter your branchName");
            String s=sc.next();
            System.out.println("Enter your accountno");
            String act=sc.next();
          if(s.equals("Nizamabad")){
                while(!(check(Nizamabad,act))){
                    System.out.println("Enter correct password");
                    act=sc.next();
                }
                System.out.println("You are successfully logged in");
            }
            else if(s.equals("Basar")){
                while(!(check(Basar,act))){
                    System.out.println("Enter correct password");
                    act=sc.next();
                }
                System.out.println("You are successfully logged in");
            }
         String  exit="No";
        while(!(exit.equals("Yes"))){
            System.out.println("Enter your operation:");
            String st=sc.next();
            switch(st){
                case "credit":
                  System.out.println("Enter your amount to creadit");
                  double am=sc.nextDouble();
                  a.credit(am,a); 
                break;
                case "debit":
                  System.out.println("Enter your amount to debit");
                  double ad=sc.nextDouble();
                  a.debit(ad,a);
                 break;
                case "displaybalance":
                  a.getbalance(a);
                break;
                case "exit":
                  System.out.println("Exit your application");
                  exit=sc.next();
            }
          }
            
        }

    }