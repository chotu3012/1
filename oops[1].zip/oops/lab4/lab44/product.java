import java.util.*;
class Amazon{
  String productname;
  String company;
  int quantity;
  double price;
 public Amazon(String pd,String c,int qua,double pr){
 productname=pd;
 company=c;
 quantity=qua;
 price=pr;
}
}
class Flipkart{
 String productname;
 String company;
 int quantity;
 double price;
 public Flipkart(String pd,String c,int qua,double pr){
 productname=pd;
 company=c;
 quantity=qua;
 price=pr;
}
}
public class product{
public static boolean  find(String p,Amazon a[], String c ){
  for(int i=0;i<a.length;i++){
    if(p.equals(a[i].productname) && c.equals(a[i].company) ){
       return true;
    }
  }
  return false;
}
public static double  cal1(String p,Amazon a[],int q ,String c){
  Scanner sc=new Scanner(System.in);
  for(int i=0;i<a.length;i++){
    if(p.equals(a[i].productname) && c.equals(a[i].company) ){
      if(q>a[i].quantity){
        System.out.println("Product quantity is less");
        break;
      }
      a[i].quantity=a[i].quantity-q;
      double cost=(a[i].price)*q;
      System.out.println("Are you  a hdfc holder");
      String s=sc.next();
       if(cost>50000){
       double k=(cost*15/100);
       cost=cost-k;
      }
      if(s.equals("yes")){
        double k=(cost*10/100);
          cost=cost-k;
      }

      return cost;
    }
  }
  return -1;
}
public static double  cal2(String p,Flipkart f[],int q ,String c){
  Scanner sc=new Scanner(System.in);
  for(int i=0;i<f.length;i++){
    if(p.equals(f[i].productname) && c.equals(f[i].company) ){
      if(q>f[i].quantity){
        System.out.println("Product quantity is less");
        break;
      }
      f[i].quantity=f[i].quantity-q;
      double cost=(f[i].price)*q;
       System.out.println("Are you  a rgukt student:");
      String s=sc.next();
       if(cost>30000){
        double k=(cost*5/100);
         cost=cost-k;
      }
      if(s.equals("yes")){
        double k=(cost*30/100);
        cost=cost-k;
      }
      return cost;
    }
  }
  return -1;
}
public static boolean  find1(String p,Flipkart f[],String c){
  for(int i=0;i<f.length;i++){
    if(p.equals(f[i].productname ) && c.equals(f[i].company)){
       return true;
    }
  }
  return false;
}
public static void check(String p,String c,int q,Amazon a[],Flipkart f[]){
if(find(p,a,c) && find1(p,f,c)){
double p1=cal1(p,a,q,c);
double p2=cal2(p,f,q,c);
System.out.println("cost for amazon is"+p1);
System.out.println("cost for flipkart is"+p2);
if(p1<p2){
System.out.println("you can buy from Amazon"); 
}
else{
System.out.println("you can buy from Flipkart"); 
}
}
else if(find(p,a,c) && !(find1(p,f,c))){
System.out.println("you can buy from Amazon"); 
}
else if(!find(p,a,c) && (find1(p,f,c))){
System.out.println("you can buy from Flipkart"); 
}
else{
  System.out.println("Product is not available in both Amazon and Flipkart");
}
}
public static void main(String args[]){
 Scanner sc=new Scanner(System.in);
 Amazon a[]=new Amazon[3];
 a[0]=new Amazon("tripod","hkmike",12,20000);
 a[1]=new Amazon("camera","sony",2,48000);
 a[2]=new Amazon("Telvision","Samsung",2,48000);
 Flipkart f[]=new Flipkart[3];
 f[0]=new Flipkart("tripod","hkmike",12,10000);
 f[1]=new Flipkart("camera","sony",2,30000);
 f[2]=new Flipkart("Telvision","Samsung",3,56000);
 System.out.println("Enter the product required");
 String s=sc.next();
  System.out.println("Enter the company you want to buy");
  String c=sc.next();
  System.out.println("Enter the quantiy required");
  int x=sc.nextInt();
  check(s,c,x,a,f);

}
}
