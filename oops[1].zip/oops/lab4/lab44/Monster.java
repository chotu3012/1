import java.util.*;
class mon{
String name;
public mon(String n){
this.name=n;
}
public void attack(){
System.out.println("I am gonna attack");
}
}
class Firemonster extends mon{
    public Firemonster(String s){
        super(s);
    }
    public void attack(){
        System.out.println("Firemonster is attacking");
    }
}
class Watermonster extends mon{
    public Watermonster(String s){
        super(s);
    }
    public void attack(){
        System.out.println("Watermonster is attacking");
    }
}
class Stonemonster extends monster{
    public Stonemonster(String s){
        super(s);
    }
    public void attack(){
        System.out.println("Stonemonster is attacking");
    }
}
class Monster{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
       monster m=new  Firemonster("Firemonster");
        m.attack();
        monster fm=new  Watermonster("Watermonster");
        fm.attack();
        monster sm=new Stonemonster("Stonemonster");
        sm.attack();


    }
}
