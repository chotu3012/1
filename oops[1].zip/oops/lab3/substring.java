import java.util.*;
public class substring {
 public static void main(String args[]) {
    Scanner sc=new Scanner(System.in);
    System.out.println("Enter a StRING:");
    String s =sc.next();
    System.out.println("enter the starting string");
    String s2=sc.next();
    System.out.println("enter the ending string");
    String s3=sc.next();
    int k=s.indexOf(s2);
    int l=s.indexOf(s3);
    if(k==-1 ||l==-1){
      System.out.println("that substring not exists");  
    }
    else{
    String s4=s.substring(k, l+s3.length());
    System.out.println(s4.startsWith(s2));
    System.out.println(s4.endsWith(s3));
    System.out.println(s4);
    }
    //System.out.println(s.substring(0, 0))
 }  
}
