rj import java.util.Scanner;
class charoccur{
    public static int find(char ch,String s){
        char arr[]=s.toCharArray();
        int i=0;
        int count=0;
        while(i<s.length()){
            int k=s.indexOf(ch);
            if(k==i){
            arr[i]='/';
            s=new String(arr);
            count++;
            }
            i++;
        }
        return count;
    }
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        System.out.println("s1:");
        String s1=sc.next();
        System.out.println("Frequency of a character is");
        char ch='o';
        System.out.println(find(ch,s1));
    }
}