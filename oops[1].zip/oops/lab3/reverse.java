import java.util.*;
public class reverse {
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a String:");
        String s=sc.next();
        StringBuilder s1=new StringBuilder(s);
        int i=0;
        int j=s.length()-1;
        while(i<=j){
            char temp=s1.charAt(j);
            s1.setCharAt(j,s1.charAt(i));
            s1.setCharAt(i,temp);
            j--;
            i++;
        }
        System.out.println("reversed string is");
        System.out.println(s1);
    }

    
}
