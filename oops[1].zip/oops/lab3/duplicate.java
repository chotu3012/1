import java.util.*;
public class duplicate {
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        ArrayList<Integer> arr=new ArrayList<>();
        while(arr.size()<5){
            System.out.println("enter a nbr");
            int a=sc.nextInt();
            if(a<=10 || a>=100){
            while(a<=10 || a>=100){
                 System.out.println("Enter nbr in range");
                 a=sc.nextInt();
            }
        }
           if(a>=10 || a<=100){
            if((arr.contains(a))){
             System.out.println("enter another nbr");
            continue;
            }
            else{
                arr.add(a);
            }
        }
        System.out.println("unique numbers are");
        for(int i=0;i<arr.size();i++){
            System.out.println(arr.get(i));
        }
    }
    
}
}
