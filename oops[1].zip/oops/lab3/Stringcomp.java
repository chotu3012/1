import java.util.*;
class Stringcomp{
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        System.out.println("s1:");
        String s1=sc.next();
        System.out.println("s2:");
        String s2=sc.next();
        if(s1.compareTo(s2)==0){
            System.out.println("equal");
        }
        else{
            System.out.println("notequal");
        }
    }
}