import java.util.*;
public class dice {
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        int k=0;
        int count=0;
        int n=0;
        while(k<3){
            System.out.println("Its 1st player turn");
            n=sc.nextInt();
            if(n<1 || n>6){
                System.out.println("enter valid number");
            }
            System.out.println("Its 2nd player turn");
            int h2=(int)(Math.random()*6)+1;
            System.out.println(h2);
            if(n==h2){
                count++;
            }
            k++;
        }
        System.out.println("successful attempts are");
        System.out.println(count);
    }
    
}
