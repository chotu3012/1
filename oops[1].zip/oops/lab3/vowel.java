import java.util.*;
public class vowel {
    public  static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter your StRING:");
        String s =sc.next();
        int v=0;
        int c=0;
        for(int i=0;i<s.length();i++){
            char ch=s.charAt(i);
            if((ch>= 65 && ch<=90) || (ch>= 97 && ch<=122) ){
            if(ch=='A' || ch=='E'|| ch=='I'|| ch=='O'|| ch=='U'|| ch=='a'|| ch=='e'|| ch=='i'|| ch=='o'|| ch=='u'){
                System.out.println(ch);
                v++;
            }
            else{
                c++;
            }
        }
    }
    System.out.println("no.of vowels are"+v);
     System.out.println("no.of consonants are"+c);
    
}
}
