import java.util.*;
class emp{
    String empname;
    int empid;
    int empage;
    String empgen;
    int empsal;
    String empadres;
    public emp(String emp,int id,int age,String gen,int sal,String adress){
        this.empname=emp;
         this.empid=id;
          this.empage=age;
           this.empgen=gen;
            this.empadres=adress;
            this.empsal=sal;
    }
}
class employee{
    public static void check(int a,emp arr[]){
        int c=0;
        for(int i=0;i<arr.length;i++ ){
            if(a==arr[i].empid){
                c=1;
                System.out.println(arr[i].empage+" "+arr[i].empname+" "+arr[i].empgen+" "+arr[i].empsal);
                break;
            }
        }
        if(c==0){
        System.out.println("not able to find id");
        }
    }
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        emp arr[]=new emp[3];
        arr[0]=new emp("varun",1234,12,"male",23000,"hyderabad");
        arr[1]=new emp("abhi",1453,28,"male",25000,"Warangal");
        arr[2]=new emp("mona",1186,16,"female",27000,"karimnagar");
        int a=0;
        while(a!=-1){
            System.out.println("enter id");
            a=sc.nextInt();
            check(a,arr);
        }
    }
}