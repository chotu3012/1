import java.util.*;
class bstall{
    String BookName[]={"Deadanddog","Alliswell","AtomicHabits"};
    String bookAuthor[]={"James","charles","joebiden"};
    int count[]={5,2,3,4}; 
}
public class library {
    public static void find(String s,bstall b[]){
        int c=0;
        for(int i=0;i<b.BookName.length;i++){
            if(b.BookName[i].equals(s) && b.count[i]==0){
                c=1;
               
               
               
                System.out.println("sorry Book is out of stock");
            }
            if(b.BookName[i].equals(s) && b.count[i]>0){
                c=1;
                b.count[i]=b.count[i]-1;
                System.out.println("you bought the book "+b.BookName[i]);
                System.out.println("remaining count of book is"+b.count[i]);
            }
        }
        if(c!=1){
            System.out.println("book is not available in library");
        }
        
    }
    public  static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        bstall b=new bstall();
        int x=0;
        while(x!=-1){
        System.out.println("Enter the bookName");
        String s=sc.next();
        find(s,b);
        x=sc.nextInt();
        }
        
    }
    
}
