import java.util.*;
class product{
    String pname;
    int prid;
    int quantity;
    int price;
    public product(String name,int id,int quant,int p){
        this.pname=name;
        this.prid=id;
        this.quantity=quant;
        this.price=p;
    }
}
class shop{
    static int wholep=0;
     public static int findp(int pid,int quant,product p[]){
        int cost=0;
        for(int i=0;i<p.length;i++){
            if(p[i].prid==pid && quant<=p[i].quantity){
                cost=cost+(quant)*p[i].price;
                p[i].quantity=p[i].quantity-quant;
            }
        }
        if(cost==0){
            return -1;
        }
        return cost;
    }
    public static int check(int pid,product p[]){
        int ch=0;
          for(int i=0;i<p.length;i++){
            if(p[i].prid==pid && p[i].quantity!=0){
                return 1;
            }
        }
        return 0;
    }
    public static void find(int pid,product p[]){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter Quantity");
        int quanty=sc.nextInt();
        int sum=findp(pid,quanty,p);
              while(sum==-1){
              System.out.println("product is less in stck");
              System.out.println("enter less quantity");
              quanty=sc.nextInt();
              sum=findp(pid,quanty,p);
              }
         System.out.println("price of product is"+sum);
        wholep=wholep+sum;
    }
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        product p[]=new product[5];
        p[0]=new product("colgate",1,10,24);
        p[1]=new product("Shampoo",2,25,3);
        p[2]=new product("dal",3,21,56);
        p[3]=new product("comb",4,24,26);
        p[4]=new product("santoor",5,34,12);
        System.out.println("Enter product id");
            int pid=sc.nextInt();
            while(pid!=-1){
            int i=check(pid,p);
            while(i==0){
              System.out.println("product is unavailable");
              System.out.println("enter another product");
              pid=sc.nextInt(); 
              i=check(pid,p);    
            }
            switch(pid){
                case 1:
                find(pid,p);
                break;
                case 2:
                find(pid,p);
                break;
                case 3:
                find(pid,p);
                break;
                case 4:
                find(pid,p);
                break;
                case 5:
                find(pid,p);
                break;

            }
            System.out.println("enter another product");
            pid=sc.nextInt();



        }
        System.out.println("Total price of all poducts is"+wholep);

    }
}