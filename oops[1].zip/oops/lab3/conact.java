import java.util.*;
class concat{
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        System.out.println("s1:");
        String s1=sc.next();
        System.out.println("s2:");
        String s2=sc.next();
        System.out.println("String is  "+s1.concat(s2));
    }
}