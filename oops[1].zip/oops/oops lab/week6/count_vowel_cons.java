import java.util.*;
class count_vowel_cons{
   public static void main(String args[]){
      
      Scanner inp=new Scanner(System.in);
      String str=inp.nextLine();
    // System.out.println("your original String is "+str);
      int count=0;
   for(int i=0;i<str.length();i++){
     if(str.charAt(i)=='a' || str.charAt(i)=='e' || str.charAt(i)=='i' || str.charAt(i)=='o' || str.charAt(i)=='u'){
     System.out.print(str.charAt(i)+" ");
       count++;
     }
     
   }
    System.out.println();
   System.out.println("no. of vowels are "+count);
    System.out.print("no.of consonants are "+ (str.length() - count));
 
 
 }
}
