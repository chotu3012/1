import java.util.*;
class StringsC{
   public static void main(String args[]){
      
      String name="meghana";
      String naam= new String("meghana");
      
      if(name.equals(naam)){
      System.out.println("Strings are matched");
      }
      else{
      System.out.println("Strings are not matched");
      }
      
   }
