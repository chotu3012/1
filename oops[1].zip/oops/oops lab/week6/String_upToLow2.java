
class namimport java.util.*;
class String_upToLow2{
   public static void main(String args[]){
      
      Scanner inp=new Scanner(System.in);
      String str=inp.nextLine();
      System.out.println("your original String is "+str);
      
      
      
      System.out.println("CHANGED sTRING IS "+str.toLowerCase());
   }
 }
