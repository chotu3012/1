import java.util.*;
class reverse_string{
   public static void main(String args[]){
      
      Scanner inp=new Scanner(System.in);
      String str=inp.nextLine();
   System.out.println("your original String is "+str);
   String str1="";
   for(int i= 0;i<str.length() ;i++){
     
     str1 = str1+str.charAt(str.length() -i-1);
     }
     
   
 
   System.out.println("reverse is "+str1);
 
 
 }
 }

