import java.util.*;import java.util.*;
class concatenation{
   public static void main(String args[]){
      
      Scanner inp=new Scanner(System.in);
      String str1=inp.nextLine();
    // System.out.println("your original String is "+str);
      
      String str2=inp.next();
     
      System.out.println(str1.concat(str2));
   }
 }

