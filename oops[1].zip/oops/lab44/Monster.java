class monster{
String name;
public monster(String n){
this.name=n;
}
public void attack(){
System.out.println("I am gonna attack");
}
}
