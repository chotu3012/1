package dept;
import dept.*;
public class eee implements department{
    public  void displaysubjects(){
          System.out.println("bee");
         System.out.println("machines");
         System.out.println("beee");
         System.out.println("powersystems");
     }
}
