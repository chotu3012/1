package dept;
import dept.*;
public class ece implements department{
     public  void displaysubjects(){
          System.out.println("signals");
         System.out.println("dec");
         System.out.println("aec");
         System.out.println("controldsystems");
     }
}
