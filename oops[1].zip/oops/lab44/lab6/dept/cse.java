package dept;
import dept.*;
public class cse implements department{
    public void displaysubjects(){
          System.out.println("oops");
         System.out.println("dsa");
         System.out.println("daa");
         System.out.println("Os");
     }
}
