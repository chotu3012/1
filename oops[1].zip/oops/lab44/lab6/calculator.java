package calculator;
interface cal{
  int  add(int a,int b);
  int  multiply(int a,int b);
  int sub(int a,int b);
  int div(int a,int b);
}
