package dept;
interface department{
   void displaysubjects();
}
