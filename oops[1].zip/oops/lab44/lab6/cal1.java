package calculator;
import calculator.cal;
public class cal1 implements cal{
  public  int add(int a,int b){
    return a+b;
  }
  public int multiply(int a,int b){
      return a*b;
  }
  public int sub(int a,int b){
      return a*b;
  }
  public int div(int a,int b){
     return a/b;
  }
}

