import java.util.*;
class Amazon{
  String productname;
  String company;
  int quantiy;
  double price;
 public Amazon(String pd,String c,int qua,double pr){
 productname=pd;
 company=c;
 quantiy=qua;
 price=pr;
}
}
class Flipkart{
 String productname;
 String company;
 int quantiy;
 double price;
 public Flipkart(String pd,String c,int qua,double pr){
 productname=pd;
 company=c;
 quantiy=qua;
 price=pr;
}
}
public class product{
public static void check(String p,String c,int q,Amazon a[],Flipkart f[]){
if(find(p,a) && find(p,f)){
double p1=cal1(p,a);
double p2=cal2(p,f);
if(p1<p2){
System.out.println("you can buy from Amazon"); 
}
else{
System.out.println("you can buy from Flipkart"); 
}
}
else if(find(p,a) && !(find(p,f)){
System.out.println("you can buy from Amazon"); 
}
else

public static void main(String,args[]){
 Scanner sc=new Scanner(System.in);
 Amazon a[]=new Amazon[3];
 a[0]=new Amazon("tripod","hkmike",12,20000);
 a[1]=new Amazon("camera","sony",2,48000);
 a[2]=new Amazon("Telvision","Samsung",2,48000);
 Flipkart f[]=new Flipkart[3];
 f[0]=new Flipkart("tripod","hkmike",12,10000);
 f[1]=new Flipkart("camera","sony",2,30000);
 f[2]=new Flipkart("Telvision","Samsung",3,56000);
 System.out.println("Enter the product required");
 String s=sc.next();
  System.out.println("Enter the company you want to buy");
  String c=sc.next();
  System.out.println("Enter the quantiy required");
  int x=sc.nextInt();
  check(s,c,x,a,f);

}
