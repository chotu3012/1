class shape{
public void get area(){

}
