import java.util.*;
class vechile{
String company;
String model;
double mileage;
double fuelcapacity;
double displacement;
public  vechile(String co,String mo,double mi,double fue,double dis){
 company=co;
 model=mo;
 mileage=mi;
 fuelcapacity=fue;
 displacement=dis;
}
}
class twowheeler extends vechile{
String tyretype;
String headlamp;
String usereviews[]=new String[2];
String rearbrake;
String frontbrake;
public twowheeler(String co,String mo,double mi,double fue,double dis,String tt,String hd,String user[],String rr,String fr){
 super(co,mo,mi,fue,dis);
 tyretype=tt;
 headlamp=hd;
 for(int i=0;i<2;i++){
 usereviews[i]=user[i];
 }
rearbrake=rr;
frontbrake=fr;
}
}
class fourwheeler extends vechile{
 String Airconditioner;
 String airbags;
 String powersteering;
 String sensewiper;
public  fourwheeler(String co,String mo,double mi,double fue,double dis,String ar,String ab,String ps,String sw){
    super(co,mo,mi,fue,dis);
    Airconditioner=ar;
    airbags=ab;
    powersteering=ps;
    sensewiper=sw;
}
}
public class VECHILE{
public static void check1(twowheeler tw[]){
int min=Integer.MIN_VALUE;
String s="";
String mo="";
for(int i=0;i<tw.length;i++){
if(min<tw[i].mileage){
min=(int)tw[i].mileage;
s=tw[i].company;
mo=tw[i].model;
}
} 
System.out.println("the best two wheeler is"+s+"which has a model of"+mo);
}
public static void check(twowheeler tw[],fourwheeler fw[]){
int min=Integer.MIN_VALUE;
String s="";
String mo="";
String h="";
for(int i=0;i<tw.length;i++){
if(min<tw[i].mileage){
min=(int)tw[i].mileage;
s=tw[i].company;
mo=tw[i].model;
h="twowheeler";
}
}
for(int j=0;j<fw.length;j++){
if(min<fw[j].mileage){
min=(int)fw[j].mileage;
s=fw[j].company;
mo=fw[j].model;
h="fourwheeler";
}
}
System.out.println("the best wheeler "+h+" which has company of "+s+" a model of "+mo);
}
public static void check2(fourwheeler fw[]){
int min=Integer.MIN_VALUE;
String s="";
String mo="";
for(int i=0;i<fw.length;i++){
if(min<fw[i].mileage){
min=(int)fw[i].mileage;
s=fw[i].company;
mo=fw[i].model;
}
}
System.out.println("the best four wheeler is"+s+"which has a model of"+mo);
}
public static void main(String args[]){
Scanner sc=new Scanner(System.in);
twowheeler tw[] =new twowheeler[2];
String a1[]={"itiisgood","superbbike"};
String a2[]={"itis nice","superbbike"};
   tw[0]=new twowheeler("honda","model-1",56,23,100,"flat","btight",a1,"diskbrake","drumbrake");
   tw[1]=new twowheeler("pulsar","model-2",87,29,132,"highperformance","bright",a2,"drumbrake","diskbrake");
   fourwheeler fw[]=new fourwheeler[2];
   fw[0]=new fourwheeler("audi","model-2",  87,29,132,"fresh","spacious","highpower","clean");
   fw[1]=new fourwheeler("benz","model-1",90,23,100,"portable","large","lowpower","large");
   System.out.println("which type of vechiles you want to check");
   String s=sc.next();
   switch(s){
   case "twowheeler":
   check1(tw);
   break;
   case "fourwheeler":
   check2(fw);
   break;
   case "both":
   check(tw,fw);
   break;
   }
   
}
}

