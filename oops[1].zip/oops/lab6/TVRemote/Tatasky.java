package TVRemote;
import TVRemote.*;
 public class Tatasky implements Remote {
    public void switchon(){
        System.out.println("Welcome to the Tatasky");
    }
    public void switchoff(){
        System.out.println("Switched off");
    }
 public void starsportschannel(){
        System.out.println("Welcome to the Starsportschannel");
    }
    public void NGCchannel(){
        System.out.println("Welcome to the NGCchannel");
    }
    public void Discoverychannel(){
        System.out.println("Welcome to the Discoverychannel "); 
    }
     public void Starmovieschannel(){
         System.out.println("Welcome to the Starmovieschannel "); 
     }
    
}
