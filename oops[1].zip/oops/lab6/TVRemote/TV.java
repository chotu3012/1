package TVRemote;
interface Remote{
    void switchon();
    void switchoff();
    void starsportschannel();
    void NGCchannel();
    void Discoverychannel();
    void Starmovieschannel();
}
