package Mseva;
import Mseva.*;
public class Msevaa implements display{
    public Msevaa(){
        System.out.println("Welcome to Mseva");
    }
    public void checkdisease(patient p){
        if(p.symptoms[0].equals("Muscleache") && p.symptoms[1].equals("fever")){
            System.out.println(p.pname+"has suffering with Acute Pancreattis");
        }
        if(p.symptoms[0].equals("fever") && p.symptoms[1].equals("fatigue")){
            System.out.println(p.pname+"has suffering with Appendictis");
        }
         if(p.symptoms[0].equals("fever") && p.symptoms[1].equals("fatigue")){
            System.out.println(p.pname+"has suffering with Panreatic Cancer");
        }
         if(p.symptoms[0].equals("skinallergy") && p.symptoms[1].equals("low bp")){
            System.out.println(p.pname+"has suffering with Bladder Cancer");
        }
    }
}
