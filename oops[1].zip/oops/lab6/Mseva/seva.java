package Mseva;
import Mseva.*;
interface  display{
    void checkdisease(patient p);
}
