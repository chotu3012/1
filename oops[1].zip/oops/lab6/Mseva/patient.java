package Mseva;
public class patient {
    public String pname;
    int age;
    public String symptoms[]=new String[2];
    public patient(String p,int a, String s[]){
        pname=p;
        age=a;
        for(int i=0;i<s.length;i++){
            System.out.println(s[i]);
            symptoms[i]=s[i];
        }
    } 
}
