import TVRemote.*;
import java.util.*;
public class Tvchoose {
    public static void main(String args[]) {
        Scanner sc=new Scanner(System.in);
        Tatasky tv =new Tatasky();
        int x=0;
        while(x!=6){
              System.out.println("Enter your operation:");
              x=sc.nextInt();
            switch(x){
                case 1:
                   tv.switchon();
                   break;
                case 2:
                   tv.starsportschannel();
                    break;
                 case 3:
                  tv.NGCchannel();
                   break;
                 case 4:
                   tv.Discoverychannel();
                    break;
                  case 5:
                  tv.Starmovieschannel();
                   break;
                  case 6:
                  tv.switchoff(); 
                   break;       
            }
        }

    }
}
