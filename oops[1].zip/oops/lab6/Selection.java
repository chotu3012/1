import admission.*;
import java.util.*;
public class Selection {
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter no.of students");
        int n=0;
        n=sc.nextInt();
        student Students[]=new student[n];
        Students[0]=new student(94,96,80,90);
        Students[1]=new student(84,76,20,50);
        Students[2]=new student(92,98,85,92);
        Students[3]=new student(52,78,83,94);
        //WE can get input from user regarding marks
        for(int i=0;i<Students.length;i++){
            if(Students[i].elgible(Students[i])){
                int k=i+1;
                System.out.println("student"+k+"   is elgible for admission");
            }
        }
    }   
}
