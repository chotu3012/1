import Mseva.*;
import java.util.*;
public class patientd {
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        int n=0;
        System.out.println("Enter total no.of patients:");
        n=sc.nextInt();
        Msevaa m=new Msevaa();
        patient p[]=new patient[n];
        String sp[]=new String[2];
        for(int i=0;i<p.length;i++){
            System.out.println("Enter the patient name");
            String s=sc.next();
            System.out.println("Enter the symptoms");
            for(int j=0;j<2;j++){
                String s1=sc.next();
                sp[j]=s1;
            }
            p[i]=new patient(s, 50,sp);
            m.checkdisease(p[i]);
        }
    }
    
}
