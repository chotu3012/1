package admission;
import admission.*;
public class student implements select  {
    double maths;
    double physics;
    double chemistry;
    double english;
    public student(double m,double p,double c,double e){
        maths=m;
        physics=p;
        chemistry=c;
        english=e;
    }
    public boolean elgible(student s){
        double sum=(s.maths+s.physics+s.chemistry+s.english)/4;
        if(s.maths>=90 && s.physics>=95&& s.chemistry>=70 && s.english>=80 && sum>=80){
            return true;
        }
        else{
            return false;
        }
    } 
}
