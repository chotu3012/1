package admission;
import admission.*;
interface select{
    boolean elgible(student s);
}
