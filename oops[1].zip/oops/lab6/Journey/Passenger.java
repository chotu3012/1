package Journey;
public class Passenger {
    public String type;
    public int number; 
    public Passenger(String t,int n) {
        type=t;
        number=n;
    } 
}
