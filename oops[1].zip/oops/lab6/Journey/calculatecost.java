package Journey;
import Journey.*;
public class calculatecost {
    public double totalfare(Passenger passenger[]){
        double faircost=100;
        double sum=0;
        for(int i=0;i<passenger.length;i++){
            if(passenger[i].type.equals("children")){
                sum=0;
            }
            else if(passenger[i].type.equals("student")){
                double dis=(faircost*30)/100;
                sum=sum+((faircost-dis)*passenger[i].number);
            }
            else if(passenger[i].type.equals("seniorcitizens")){
                double dis=(faircost*50)/100;
                sum=sum+((faircost-dis)*passenger[i].number);
            }
             else if(passenger[i].type.equals("citizens")){
                sum=sum+((faircost)*passenger[i].number);
            } 
            System.out.println("sum is"+sum);
        }
        return sum;
    }
}
