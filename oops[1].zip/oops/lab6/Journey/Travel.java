package Journey;
import Journey.Passenger;
interface reservation_cost{
    double totalfare(Passenger passenger[]);
}
