import Journey.*;
import java.util.*;
public class mytravel {
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        Passenger passenger[]=new Passenger[4];
        calculatecost cost=new calculatecost();
        System.out.println("Enter your details of people in Journey");
        String s="";
        int num=0;
        for(int i=0;i<4;i++){
            System.out.println("Enter type of passenger");
            s=sc.next();
            System.out.println("Enter Number of"+s);
            num=sc.nextInt();
            passenger[i]=new Passenger(s,num);
        }
        System.out.println(cost.totalfare(passenger));

    }  
}
