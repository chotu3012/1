package sounds;
import sounds.dolby;
public class Podcast implements dolby {
    public void playDolby(String songname){
        if(songname=="play hayyodasound"){
            System.out.println("playing Hayyoda");
        }
        else if(songname=="play kannulosound"){
            System.out.println("playing kannulo");
        }
        else if(songname=="play terebinasound"){
            System.out.println("playing terebina");
        }
        else{
            System.out.println("Song is not available in the playlist");
        }
       
    }
}
