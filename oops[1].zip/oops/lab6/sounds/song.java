package sounds;
interface dolby{
    void playDolby(String songname);
}