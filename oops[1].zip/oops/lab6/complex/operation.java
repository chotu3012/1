package complex;

public class operation {
    public void add( Arith a1,Arith a2){
        int x=a1.ip+a2.ip;
        int y=a1.rp+a2.rp;
        char ch='+';
        if(x<0){
            ch='-';
        }
        System.out.println("Added value is"+y+ch+x+"i");
    }
     public void subtract( Arith a1,Arith a2){
        int x=a1.ip-a2.ip;
        int y=a1.rp-a2.rp;
         char ch='+';
        if(x<0){
            ch='-';
            x=Math.abs(x);
        }
        System.out.println("subractedvalue is"+y+ch+x+"i");
    }
}
