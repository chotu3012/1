package complex;
public class Arith {
    public int ip;
    public int rp;
    public Arith(){
        this.ip=0;
        this.rp=0;
    }
    public Arith(int i,int r){
        ip=i;
        rp=r;
    }  
}
