import sounds.*;
import java.util.*;
public class songlist {
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        Podcast p=new Podcast();
        int x=0;
        while(x!=-1){
            System.out.println("Enter your songname");
            String s=sc.next();
            p.playDolby(s);
            System.out.println("enter x");
            x=sc.nextInt();
        }

    }


    
}
