import complex.*;
import java.util.*;
public class math {
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        int x=sc.nextInt();
        operation op=new operation();
        while(x!=-1){
            System.out.println("Enter firstnbr details");
            System.out.println("Enter the imgpart of nbr:");
            int a=sc.nextInt();
            System.out.println("Enter the realpart  of nbr:");
            int b=sc.nextInt();
            Arith a1=new Arith(a,b);
            System.out.println("Enter secondnbr details");
            System.out.println("Enter the imgpart of nbr:");
            int c=sc.nextInt();
            System.out.println("Enter the  realpart  of nbr:");
            int d=sc.nextInt();
            Arith a2=new Arith(c,d);
            op.subtract(a1,a2);
            op.add(a1,a2);
            /*System.out.println("Enter your operation");
            String o=sc.next();
            switch(o){
                case "add":
                    op.add(a1,a2);
                    break;
                case "subtract"  :
                    op.subtract(a1, a2);
                    break;  
            }*/
            System.out.println("Enter x value");
            x=sc.nextInt();
        }
        

    } 
}
