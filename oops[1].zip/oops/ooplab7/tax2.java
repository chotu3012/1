import audit .*;
import java.util.*;


public class tax2 {
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        taxacc t=new taxacc();
        System.out.println("Enter your home Expenditure:");
        double he=sc.nextDouble();
        t.hmexp(he);
        System.out.println("Enter your Health Expenditure:");
        double hhe=sc.nextDouble();
        t.heexp(hhe);
         System.out.println("Enter your vecile Expenditure:");
        double vee=sc.nextDouble();
        t.vexp(vee);
         System.out.println("Enter your personal family Expenditure:");
        double pff=sc.nextDouble();
        t.pfexp(vee);
         System.out.println("Enter your miscelle Expenditure:");
        double mi=sc.nextDouble();
        t.miexp(mi);
          System.out.println("Enter tax you had paid:");
        double tt=sc.nextDouble();
        t.taxpaid(tt);

        try{
            System.out.println("Enter your income");
            double inc=sc.nextDouble();
            System.out.println(t.taxcecker(inc));
        }
        catch(exceed e){
            System.out.println(e);
        }
    }
    
}