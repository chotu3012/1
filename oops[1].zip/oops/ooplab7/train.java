import java.util.*;
class agent extends Exception{
    public agent(String str){
        super(str);
    }
}
class pair{
    String coa;
    int nu;
    public pair(String str,int n){
        coa=str;
nu=n;
    }
}

public class train {
    public static pair[] allocate (int n,String s) throws agent{
    boolean s1[]=new boolean[71];
    boolean s2[]=new boolean[71];
    boolean b1[]=new boolean[71];
    boolean b2[]=new boolean[71];
     pair arr[]=new pair[n];
    if(n<6 &&(s.equals("AC")) || s.equals("sleeper")){
        
        
        if(s.equals("AC")){
            int count=0;
            
            while(count!=n){
               
                int k=(int)(Math.random()*70)+1;
                
                if(k<71 && b1[k]==false){
                    b1[k]=true;
                    arr[count]=new pair("b1",k);
                    count++;
                }
                else if(k<71 && b2[k]==false){
                     b2[k]=true;
                    arr[count]=new pair("b2",k);
                    count++;
                }
            }
        }
            if(s.equals("sleeper")){
            int count=0;
           
            while(count!=n){
                int k=(int)Math.random()*70;
                if(k<71&& s1[k]==false){
                    s1[k]=true;
                    arr[count]=new pair("s1",k);
                    count++;
                }
                else if(k<71 && s2[k]==false){
                     s2[k]=true;
                    arr[count]=new pair("s2",k);
                    count++;
                }
            }
        }
        return arr;

    }
    else{
       throw new agent("You are a agent");
    }
  

}
    public  static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter no.of births");
        int n=sc.nextInt();
        System.out.println("Enter the class");
        String s=sc.next();
        try{
        pair p[]=allocate(n,s);
        for(int i=0;i<p.length;i++){
            System.out.println(p[i].coa+" "+p[i].nu);
        }
    }
    catch( agent e){
        System.out.println(e);
    }
    
}   
}
