import java.util.*;
class p1{
public static void main(String[] args){
    Scanner sc=new Scanner(System.in);
try{
    int a=sc.nextInt();
}
catch(InputMismatchException im){
System.out.println(im);
}
finally{
System.out.println("Entered the value");
}
}
}
