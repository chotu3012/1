import Bank.*;
import java.util.*;
class bank2{
public static void main(String[] args){
   Scanner sc=new Scanner(System.in);
   String s="/";
   sbi a=new sbi();
   System.out.println("Enter your username");
        String u=sc.next();
        System.out.println("Enter your password");
        String p=sc.next();
        account acc=new account(u,p);
   while(!s.equals("exit")){
     System.out.println("Enter your operation");
     s=sc.next();
     switch(s){
      case "detail":
        try{
        a.credentialch(acc);
        }
        catch(errorm e){
             System.out.println(e);
        }
        break;
      case "credit":
        System.out.println("Enter amount to credit");
        double ap=sc.nextDouble();
        a.credit(ap,acc);
        break;
      case "debit":
       System.out.println("Enter amount to debit");
        double ad=sc.nextDouble();
        try{
        a.debit(ad,acc);
        }
        catch(excess e){
      System.out.println(e);
  }
       break;
      case "displayb":
        a.displayb(acc);
        break;
      case "exit":
       a.exit();
       s="exit";
       break;
     }
   }
}
}
