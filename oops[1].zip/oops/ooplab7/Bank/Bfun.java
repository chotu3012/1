package Bank;
import Bank.account;

import java.util.*;
public interface Bfun{
void credentialch(account a) throws errorm;
void credit(double amount,account a);
void debit(double amount,account a) throws excess;
void displayb(account a);
void exit();
}
