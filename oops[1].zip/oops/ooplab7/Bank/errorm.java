 package Bank;
 public class errorm extends Exception  
{  
    public errorm (String str)  
    {  
        // calling the constructor of parent Exception  
        super(str);  
    }  
}
