package Bank;

class pair{
  String username;
  String password;
    public pair(String u,String p){
       username=u;
       password=p;
    }
}
public class sbi implements Bfun{
    pair check[]={new pair("Monakinnera","Mona704"),new pair("raghav","ra123"),new pair("ayushman","a3333"),new pair("sagarika","sa123")};
   
   
   public void credentialch(account a) throws errorm{
 
        boolean c=false;
         for(int i=0;i<check.length;i++){
          if(check[i].username.equals(a.username) &&check[i].password.equals(a.password)){
              c=true;
          }
          }
          if(c==false){
            throw new errorm("Incorrect details");
          }
          else{
             System.out.println("you are a valid user");
          }
          }
  public void credit(double amount,account a){
     a.balance=a.balance+amount;
   
  }
  public void debit(double amount,account a) throws excess{
      if(amount>a.balance){
      throw new excess("Amount not available");
  }
  }
  public void displayb(account a){
     System.out.println("Your available balance is"+a.balance); 
  }
  public void exit(){
       System.out.println("Exited");
   }
}
