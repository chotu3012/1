package Bank;
import java.util.*;
 public class errorm extends Exception  
{  
    public errorm (String str)  
    {  
        // calling the constructor of parent Exception  
        super(str);  
    }  
}
public class excess extends Exception  
{  
    public excess (String str)  
    {  
        // calling the constructor of parent Exception  
        super(str);  
    }  
}
public interface Bfun{
void credentialch(account a) throws errorm;
void credit(double amount,account a);
void debit(double amount,account a) throws excess;
void displayb(account a);
void exit();
}
