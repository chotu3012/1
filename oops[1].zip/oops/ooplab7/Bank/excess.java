 package Bank;
 public class excess extends Exception  
{  
    public excess (String str)  
    {  
        // calling the constructor of parent Exception  
        super(str);  
    }  
}
