package Bank;
public class account{
 double balance;
 String username;
 String password;
   public  account(String un,String pw){
      username=un;
      password=pw;
   }
}
