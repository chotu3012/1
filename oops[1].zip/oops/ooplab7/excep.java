import java.util.*;
class excep{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        int arr[]=new int[5];
        String s=null;
        try{
            System.out.println("Enter an integer:");
            int x=sc.nextInt();
        }
        catch(Exception i){
            System.out.println(i.getMessage());
        }
        try{
            System.out.println("Try to acess an elemnt of array");
            int l=sc.nextInt();
            System.out.println("number is"+arr[l]);
        }
        catch(ArrayIndexOutOfBoundsException a){
              System.out.println(a.getMessage());
        }
         try{
            System.out.println("Enter a number to divide:");
            int l=sc.nextInt();
            System.out.println("number is"+25/l);
        }
        catch(ArithmeticException ae){
              System.out.println(ae.getMessage());
        }
         try{
            System.out.println("ACESS a string:");
            if(s.equals("hello")){
                System.out.println("string is"+s);
            }
            else{
                 System.out.println("not matches");
            }
            
        }
        catch(NullPointerException nu){
              System.out.println(nu.getMessage());
        }
    }
    
}