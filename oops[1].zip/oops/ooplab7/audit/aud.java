package audit;
public interface aud{
    String taxcecker(double income) throws exceed;
   void taxpaid(double tax);
   void vexp(double iexp);
   void heexp(double hexp);
   void hmexp(double hmexp);
   void pfexp(double pfexp);
   void miexp(double miexp);
}