package audit;
public class  exceed extends Exception {
    public exceed(String str){
        super(str);
    }

}
