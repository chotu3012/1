package audit;
import audit.*;
public class taxacc implements  aud {
    double expe;
    double tax;
    public String taxcecker(double income) throws exceed{
        double l=(income-expe);
        double m=(l*10/100);
        double o=l-m;
        if(tax<o){
            System.out.println("Paid amount is"+tax);
            System.out.println("requires amount is"+o);
            throw new exceed("You paid less than required,You have to pay"+(o-tax));
        }
        else{
            return "You paid tax correctly";
        }
    }
   public void taxpaid(double t){
      tax=t;
}
  public void vexp(double iexp){
      expe=expe+iexp;
   }
   public void heexp(double hexp){
      expe=expe+hexp;
   }
   public void hmexp(double hmexp){
       expe=expe+hmexp;

   }
   public void pfexp(double pfexp){
    expe=expe+pfexp;
   }
   public void miexp(double miexp){
     expe=expe+miexp;
   }
}
