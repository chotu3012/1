import java.lang.*;
import java.util.*;
class Dog{
	String name;
	String breed;
	String color;
	double height;
	String type;
	Dog(String name,String breed,String color,double height, String type)	
	{
		this.name=name;
		this.breed=breed;
		this.color=color;
		this.height=height;
		this.type=type;

	}
	
	String getBreed()
	{
		return breed;
	}
	String getName()
	{
		return name;
	}
	String type()
	{
		return breed;
    }
	String getColor()
	{
		return color;
    }
    double getHeight()
	{
		return height;
	}
}
class M2Q5
{
	public static void main(String vk[]){
	
	Dog snoopy=new Dog("snoopy","pomerian","white",1,"gaurd");
	Dog rocky=new Dog("rocky","lab","brown",3,"sniffer");
    Dog snowy=new Dog("snowy","g.sheperd","black",1,"sheperd");

	Scanner sc=new Scanner(System.in);
	String pref;
	System.out.println("Enter the breed you want");
	pref=sc.nextLine();

	if(pref.equalsIgnoreCase(snoopy.getBreed()))
		System.out.println("You might like "+snoopy.getName());
	else if(pref.equalsIgnoreCase(rocky.getBreed()))
		System.out.println("You might like "+rocky.getName());
	else
		System.out.println("You might like "+snowy.getName());
 }

}