import java.lang.*;

class TV{

	private int channel;
	private int volume;
	boolean on;
	
	public TV(){
		channel=1;
		volume=2;
    }
	void turnOn(){
     on=true;
	 System.out.println("TV turned On");
	}
	void turnOff(){
		 on=false;
		 System.out.println("TV turned Off");
		}
	void setChannel(int newChannel){
	 
		if(on && newChannel >=1 && newChannel<=40){	
			channel=newChannel;
			System.out.println("Channel is changed to "+channel);
         }

		else{
			System.out.println("Enter the valid channel(1-7) or switch On of the TV");
		}
	}
	void setVolume(int newVolume){
	 
		if(on && newVolume >=1 && newVolume<=7){
			volume=newVolume;
			System.out.println("Volume is changed to "+volume);
			}	
		else{
			System.out.println("Enter the valid volume(1-40) or switch On of the TV");
		}
	}
    
    void channelUp(){
			channel++;
			System.out.println("Channel increased");
		}
  
    void channelDown(){
			channel--;
			System.out.println("Channel decreased");
		}
  
    void volumeUp(){
			volume++;
			System.out.println("Volume increased");
		}
  
    void volumeDown(){
			volume--;
			System.out.println("Volume decreased");
		}
  }





class M2Q3{
     public static void main(String vl[])
	{
		TV t=new TV();

		t.setChannel(45);
		t.turnOn();
		t.setChannel(18);
		t.setVolume(6);
		t.channelUp();
		t.volumeDown();
		t.turnOff();
	}
}