import java.lang.*;


class Car{
	private String company;
	private double mileage;
	private double speed;
	private String color;
	
	public Car(){
		
     }
	public Car(String company,double mileage,double speed,String color){
	this.company=company;
	this.mileage=mileage;
	this.speed=speed;
	this.color=color;
     }
	double getMileage(){
	return mileage;
	}
	double getSpeed(){
	return speed;
	}
}

class M2Q4{

    public static void main(String vk[]){
			
	Car ford=new Car("ford",30.4,150,"white");
    Car toyato=new Car("toyato",28.7,170,"black");
	Car volkswagon=new Car("volkswagon",23.4,180,"blue");
	
	System.out.println("Ford mileage is "+ford.getMileage());
	System.out.println("toyato mileage is "+toyato.getMileage());
	System.out.println("volkswagon speed is "+volkswagon.getSpeed());
	System.out.println("volkswagon mileage is "+volkswagon.getMileage());
	
    }
}