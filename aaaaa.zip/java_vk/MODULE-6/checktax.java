import audit.tax;

class checktax
{
	public static void main(String vk[])
	{
		tax t=new tax(100000,30000,10000,5000,10000);
		
		t.taxChecker(100);
		
		
	}
}