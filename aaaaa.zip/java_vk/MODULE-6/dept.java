package department;

public interface dept
{
    public void displaySubjects();
	
}
