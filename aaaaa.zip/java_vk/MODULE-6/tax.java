package audit;


interface tax_
{
	abstract void taxChecker(int x);
	abstract void taxPaid(int x);
	abstract void homeExpenditure(int x);
	abstract void healthExpenditure(int x);
	abstract void vehicleExpenditure(int x);
	abstract void personalFamilyExpenditure(int x);
}

public class tax implements tax_{
	
	public int totalIncom,taxPai,homeExpenditur,healthExpenditur,vehicleExpenditur,personalFamilyExpenditur;
	
	public tax(int totalIncome,int homeExpenditure,int healthExpenditure,int vehicleExpenditure,int personalFamilyExpenditure )
	{
		totalIncom=totalIncome;
		homeExpenditur=homeExpenditure;
		vehicleExpenditur=vehicleExpenditure;
		personalFamilyExpenditur=personalFamilyExpenditure;
		healthExpenditur=healthExpenditure;
	}
	public int totalEx=homeExpenditur+healthExpenditur+personalFamilyExpenditur+vehicleExpenditur;

	public void taxChecker(int taxPai)
	{
	 if(taxPai < (totalIncom-totalEx)*0.10){
		try{
			throw new Exception();
		}
		catch(Exception e)
		{
			System.out.println("He/She not paid enough tax");
		}
	}
	else
		System.out.println("He/She paid total tax");
	}
	public void taxPaid(int x)
	{
		System.out.println("tax paid : "+x);
	}
	public void healthExpenditure(int x)
	{
		System.out.println("healthExpenditure : "+x);
	}
	public void vehicleExpenditure(int x)
	{
		System.out.println("vehicleExpenditure : "+x);
	}
	public void personalFamilyExpenditure(int x)
	{
		System.out.println(" personalFamilyExpenditure : "+x);
	}
	public void homeExpenditure(int x)
	{
		System.out.println("homeExpenditure : "+x);
	}
}