package department;

public class CSE implements dept{

    public void displaySubjects()
	{
		System.out.println("CSE Subjects are :\n..\n..\n");
	}
}