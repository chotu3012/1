import department.CSE;
import department.ECE;
import department.CE;
import department.dept;

class departments
{
	public static void main(String vk[])
	{  
		CSE cse=new CSE();
		ECE ece=new ECE();
		CE ce=new CE();
		cse.displaySubjects();
		ece.displaySubjects();
		ce.displaySubjects();
	}
}