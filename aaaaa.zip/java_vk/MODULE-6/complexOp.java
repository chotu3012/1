import java.util.Scanner;
import complex.Arith;

public class complexOp
{
	public static void main(String vk[])
	{
	 	
	 Scanner sc = new Scanner(System.in);
	 
	  System.out.println("Enter the real part of 1st complex no:");
	 int rp1=sc.nextInt();
	 int ip1=sc.nextInt();
	  System.out.println("Enter the real part of 2nd complex no:");
	  
	 int rp2=sc.nextInt();
	 int ip2=sc.nextInt();
	 
	 Arith a1=new Arith(rp1,ip1);
	 Arith a2=new Arith(rp2,ip2);
	 
	 System.out.println("a1 = "+rp1+"+"+ip1+"i");
	 System.out.println("a1 = "+rp2+"+"+ip2+"i");
	 Arith added=new Arith(rp1,ip1);
	 added.add(a1,a2);
	 System.out.println("Added value : "+added.rp+"+"+added.ip+"i");
	 Arith substract=new Arith(rp2,ip2);
	 substract.sub(a1,a2);
	 System.out.println("Subsracted value : "+substract.rp+substract.ip+"i");
	 
    }  
}