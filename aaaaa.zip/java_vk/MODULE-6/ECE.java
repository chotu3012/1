package department;

public class ECE implements dept{

    public void displaySubjects()
	{
		System.out.println("ECE Subjects are :\n..\n..\n");
	}
}