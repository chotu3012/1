package department;

public class CE implements dept{

    public void displaySubjects()
	{
		System.out.println("CE Subjects are :\n..\n..\n");
	}
}