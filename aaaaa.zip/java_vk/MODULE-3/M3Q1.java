import java.lang.*;
import java.util.*;
class M3Q1{
		public static void main(String vk[]){
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter the first string");
			String s1=sc.nextLine();
			System.out.println("Enter the second string");
			String s2=sc.nextLine();
			
			System.out.println(s1.compareTo(s2));
			
			
		}
}