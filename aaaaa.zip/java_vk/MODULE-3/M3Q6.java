import java.lang.*;
import java.util.*;

class M3Q6
{
	public static void main(String vk[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string");
		String s=sc.nextLine();
		int n=s.length();
		System.out.println("The length of the string is "+n);
	}
}