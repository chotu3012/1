import java.lang.*;
import java.util.*;


class M3Q9
{
	public static void main(String vk[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string ");
		String s=sc.nextLine();
			
		String upper=s.toUpperCase();
		System.out.println("Upper case of given string is \n"+upper);
		String lower=s.toLowerCase();
		System.out.println("Lower case of given string is \n"+lower);
	}
	
}