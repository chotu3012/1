import java.lang.*;
import java.util.*;
class M3Q4{
		public static void main(String vk[]){
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter the first string");
			String s1=sc.nextLine();
			System.out.println("Enter the second string");
			String s2=sc.nextLine();
			
			String a=s1.concat(s2);
				System.out.println("Conated string is "+a);
			
			
		}
}