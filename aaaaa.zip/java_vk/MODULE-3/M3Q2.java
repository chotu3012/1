import java.lang.*;
import java.util.*;
class M3Q2{
		public static void main(String vk[]){
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter the first string");
			String s1=sc.nextLine();
			System.out.println("Enter the second string");
			String s2=sc.nextLine();
			
			if(s1.equals(s2))	
				System.out.println("Both Strings are equal");
			
			else
				System.out.println("Both Strings are not equal");
				
			if(s1.equalsIgnoreCase(s2))
			    System.out.println("Both Strings are equal ignoring case");
			else 
				System.out.println("Both Strings are not equal ignoring case");
			
			
		}
}