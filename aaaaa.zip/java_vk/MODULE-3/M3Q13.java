import java.util.*;

public class M3Q13 {
    public static void main(String[] args) {
        int successfulAttempts = 0;
        Random random = new Random();

        System.out.println("Rolling a pair of dice 10 times...");

        for (int i = 0; i < 10; i++) {
            // Delay for 10000 milliseconds (10 seconds)
            try {
                Thread.sleep(10000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            // Rolling the dice
            int dice1 = random.nextInt(6) + 1; // Generate random number between 1 to 6 for dice 1
            int dice2 = random.nextInt(6) + 1; // Generate random number between 1 to 6 for dice 2

            System.out.println("Attempt " + (i + 1) + ": Dice 1 = " + dice1 + ", Dice 2 = " + dice2);

            // Check if it's a successful attempt (same values on both dice)
            if (dice1 == dice2) {
                System.out.println("Successful attempt!");
                successfulAttempts++;
            }
        }

        System.out.println("Number of successful attempts: " + successfulAttempts);
    }
}
