import java.lang.*;
import java.util.*;

class employee
{
	String name;
	int age;
	String gender;
	int salary;
	
	employee(String name,int age,String gender,int salary){
		this.name=name;
		this.age=age;
		this.gender=gender;
		this.salary=salary;
	}

	public String getName(){
		return name;
	}
	public  int getAge(){
		return age;
	}
	public String getGender(){
		return gender;
	}
	public  int getSalary(){
		return salary;
	}
}

class M3Q10
{      

	public static void main(String vk[])
	{
		Map<Integer,employee> empMap=new HashMap<>();
		empMap.put(18,new employee("virat",33,"male",80000));
		empMap.put(7,new employee("dhoni",40,"male",70000));
		empMap.put(45,new employee("rohit",36,"male",50000));
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Id of the employee");
		int id=sc.nextInt();
		
		if(empMap.containsKey(id))
		{
			employee emp=empMap.get(id);
			System.out.println("Employee details");
			System.out.println("Name   : "+emp.getName());
			System.out.println("Age    : "+emp.getAge());
			System.out.println("Gender : "+emp.getGender());
			System.out.println("Salary : "+emp.getSalary());
		}
		else
			System.out.println("Id not found in the list");
		
	}

}