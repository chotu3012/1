import java.util.Scanner;
import java.util.HashSet;

public class M3Q12{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        HashSet<Integer> uniqueNumbers = new HashSet<>();

        System.out.println("Enter 5 numbers between 10 and 100 inclusive:");

        int count = 0;
        while (count < 5) {
            System.out.print("Enter number #" + (count + 1) + ": ");
            int number = scanner.nextInt();

           
            if (number >= 10 && number <= 100) {
                
                if (!uniqueNumbers.contains(number)) {
                    uniqueNumbers.add(number);
                    System.out.print("Unique values entered so far: ");
                    for (int uniqueNumber : uniqueNumbers) {
                        System.out.print(uniqueNumber + " ");
                    }
                    System.out.println();
                    count++;
                } else {
                    System.out.println("Duplicate number. Enter a different number.");
                }
            } else {
                System.out.println("Please enter a number between 10 and 100 inclusive.");
            }
        }

        scanner.close();
    }
}
