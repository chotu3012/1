class Book {
    private String bookName;
    private String bookAuthor;
    private int bookCount;

    public Book(String name, String author, int count) {
        this.bookName = name;
        this.bookAuthor = author;
        this.bookCount = count;
    }

    public String getBookName() {
        return bookName;
    }

    public String getBookAuthor() {
        return bookAuthor;
    }

    public int getBookCount() {
        return bookCount;
    }

    public void setBookCount(int count) {
        this.bookCount = count;
    }
}

class Customer {
    private int customerId;
    private String customerName;
    private String customerAddress;

    public Customer(int id, String name, String address) {
        this.customerId = id;
        this.customerName = name;
        this.customerAddress = address;
    }

    public int getCustomerId() {
        return customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getCustomerAddress() {
        return customerAddress;
    }

    public void buyBook(Book book, int quantity) {
        int availableBooks = book.getBookCount();
        if (availableBooks >= quantity) {
            availableBooks -= quantity;
            book.setBookCount(availableBooks);
            System.out.println("Book purchased: " + book.getBookName());
            System.out.println("Remaining count of " + book.getBookName() + ": " + availableBooks);
        } else {
            System.out.println("Sorry, insufficient stock for " + book.getBookName());
        }
    }
}

public class M3Q14{
    public static void main(String[] args) {
        Book textbook = new Book("Java Programming", "John Doe", 50);
        Customer customer = new Customer(1, "Alice", "123 Main St");

        // Buying books
        customer.buyBook(textbook, 3);
        customer.buyBook(textbook, 10);
    }
}
