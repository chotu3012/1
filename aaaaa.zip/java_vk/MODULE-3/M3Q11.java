import java.lang.*;
import java.util.*;

public class M3Q11 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double totalRetailValue = 0.0;

        System.out.println("Enter product ID and quantity sold (Enter -1 to stop):");
		
        while (true) {
            System.out.print("Product ID (-1 to stop): ");
            int productId = scanner.nextInt();

            // Exit loop if -1 is entered
            if (productId == -1) {
                break;
            }

            System.out.print("Quantity sold: ");
            int quantity = scanner.nextInt();

            double retailPrice = 0.0;

            // Calculate retail price based on product ID using switch statement
            switch (productId) {
                case 1:
                    retailPrice = 99.90;
                    break;
                case 2:
                    retailPrice = 20.20;
                    break;
                case 3:
                    retailPrice = 6.87;
                    break;
                case 4:
                    retailPrice = 45.50;
                    break;
                case 5:
                    retailPrice = 40.49;
                    break;
                default:
                    System.out.println("Invalid Product ID");
            }

            // Calculate and accumulate total retail value
            totalRetailValue += retailPrice * quantity;
        }

        System.out.println("Total retail value of all products sold: Rs. " + totalRetailValue);

        scanner.close();
    }
}
