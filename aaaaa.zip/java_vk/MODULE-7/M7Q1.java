import java.util.*;

class M7Q1
{
	
   public static void main(String vk[])
   {
	   Scanner sc=new Scanner(System.in);
	   
	  
	   int x;
	     try{
			 
			 x=sc.nextInt(); 
		 }
		 catch(Exception e)
		 {
			 System.out.println("Enter the numeric digits");
        }	   
	
}
}