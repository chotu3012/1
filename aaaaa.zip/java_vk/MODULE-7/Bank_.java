
package bank;

interface bank_details
{   
	abstract void credentialsCheck(String Username,String password);
	abstract void credit(int amount);
	abstract void debit(int amount);
	abstract void displayBalance();
	abstract void exit();
}

public class Bank_ implements bank_details{
	
	public int bal;
	boolean bool=true;
	public String Username,password;
	
	  public Bank_(String user,String pw,int am)
	  {
		  bal=am;
		  Username=user;
		  password=pw;
	  }
	 
	public void credentialsCheck(String user,String pw)
	{
		if(!Username.equals(user) || !password.equals(pw))
		{
			try{
				throw new Exception();
			}
			catch(Exception e)
			{ 
				System.out.println("Enter the valid Username or Password");
			}
	    }
		
     }
	 public void debit(int amount)
	 {
		if(amount <= bal){
		bal-=amount;
		System.out.println("debited amount : "+amount);
		}
		else 
			System.out.println("Insufficient funds");
	 }
	 public void credit(int amount)
	 {
		bal+=amount;
		System.out.println("credited amount : "+amount);
	 }
	 
	 public void displayBalance()
	 {
		 System.out.println("Total balance: "+bal);
     }
	 public void exit()
	 { 
		System.out.println("thank you");
	 }
}