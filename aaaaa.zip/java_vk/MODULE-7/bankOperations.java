import bank.Bank_;
import java.util.*;

public class bankOperations
{
	public static void main(String vk[])
	{
		Bank_   b = new Bank_("vinay","12345678",10000);
		Scanner sc = new Scanner(System.in);
		String username,password;
		System.out.println("Enter user name ");
		username=sc.next();
		System.out.println("Enter password");
		password=sc.next();
		
		
		b.credentialsCheck(username,password);
		b.displayBalance();
		b.debit(600);
		b.displayBalance();
		b.credit(1000);
		b.debit(20000);
		b.displayBalance();
		b.credit(10000);
		b.displayBalance();
		
		
		
	}
}
