import java.lang.*;

abstract class RBI {
    public void credit() {
        System.out.println("Common credit functionality for all banks");
    }

    public void debit() {
        System.out.println("Common debit functionality for all banks");
    }

    public void displayBalance() {
        System.out.println("Common display balance functionality for all banks");
    }

    abstract void personalLoanEligibility(double annualIncome, String jobType, boolean hasProperty, boolean isFit);
    abstract void homeLoanEligibility(double annualIncome, String jobType, boolean hasProperty, boolean isFit);
    abstract void vehicleLoanEligibility(double annualIncome, String jobType, boolean hasProperty, boolean isFit);
}

class SBI extends RBI {
    @Override
    void personalLoanEligibility(double annualIncome, String jobType, boolean hasProperty, boolean isFit) {
        // Specific implementation for SBI personal loan eligibility
        // Make assumptions based on annualIncome, jobType, hasProperty, isFit
        System.out.println("SBI Personal Loan Eligibility Assessment");
    }

    @Override
    void homeLoanEligibility(double annualIncome, String jobType, boolean hasProperty, boolean isFit) {
        // Specific implementation for SBI home loan eligibility
        // Make assumptions based on annualIncome, jobType, hasProperty, isFit
        System.out.println("SBI Home Loan Eligibility Assessment");
    }

    @Override
    void vehicleLoanEligibility(double annualIncome, String jobType, boolean hasProperty, boolean isFit) {
        // Specific implementation for SBI vehicle loan eligibility
        // Make assumptions based on annualIncome, jobType, hasProperty, isFit
        System.out.println("SBI Vehicle Loan Eligibility Assessment");
    }
}

class HDFC extends RBI {
    @Override
    void personalLoanEligibility(double annualIncome, String jobType, boolean hasProperty, boolean isFit) {
        // Specific implementation for HDFC personal loan eligibility
        // Make assumptions based on annualIncome, jobType, hasProperty, isFit
        System.out.println("HDFC Personal Loan Eligibility Assessment");
    }

    @Override
    void homeLoanEligibility(double annualIncome, String jobType, boolean hasProperty, boolean isFit) {
        // Specific implementation for HDFC home loan eligibility
        // Make assumptions based on annualIncome, jobType, hasProperty, isFit
        System.out.println("HDFC Home Loan Eligibility Assessment");
    }

    @Override
    void vehicleLoanEligibility(double annualIncome, String jobType, boolean hasProperty, boolean isFit) {
        // Specific implementation for HDFC vehicle loan eligibility
        // Make assumptions based on annualIncome, jobType, hasProperty, isFit
        System.out.println("HDFC Vehicle Loan Eligibility Assessment");
    }
}

class DCB extends RBI {
    @Override
    void personalLoanEligibility(double annualIncome, String jobType, boolean hasProperty, boolean isFit) {
        // Specific implementation for DCB personal loan eligibility
        // Make assumptions based on annualIncome, jobType, hasProperty, isFit
        System.out.println("DCB Personal Loan Eligibility Assessment");
    }

    @Override
    void homeLoanEligibility(double annualIncome, String jobType, boolean hasProperty, boolean isFit) {
        // Specific implementation for DCB home loan eligibility
        // Make assumptions based on annualIncome, jobType, hasProperty, isFit
        System.out.println("DCB Home Loan Eligibility Assessment");
    }

    @Override
    void vehicleLoanEligibility(double annualIncome, String jobType, boolean hasProperty, boolean isFit) {
        // Specific implementation for DCB vehicle loan eligibility
        // Make assumptions based on annualIncome, jobType, hasProperty, isFit
        System.out.println("DCB Vehicle Loan Eligibility Assessment");
    }
}

public class M5Q5 {
    public static void main(String[] args) {
        SBI sbi = new SBI();
        sbi.credit();
        sbi.debit();
        sbi.displayBalance();
        sbi.personalLoanEligibility(800000, "Government", true, true);

        HDFC hdfc = new HDFC();
        hdfc.credit();
        hdfc.debit();
        hdfc.displayBalance();
        hdfc.homeLoanEligibility(1200000, "Private", true, true);

        DCB dcb = new DCB();
        dcb.credit();
        dcb.debit();
        dcb.displayBalance();
        dcb.vehicleLoanEligibility(500000, "Government", false, true);
    }
}
