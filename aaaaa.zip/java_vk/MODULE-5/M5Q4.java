import java.lang.*;

interface Fare {
    double getFare();
    String getAmenities();
}

class Bus implements Fare {
    private String type;
    private double farePerKm;
    private double distance;

    public Bus(String type, double farePerKm, double distance) {
        this.type = type;
        this.farePerKm = farePerKm;
        this.distance = distance;
    }

    @Override
    public double getFare() {
        return farePerKm * distance;
    }

    @Override
    public String getAmenities() {
        // Assuming amenities based on the type of bus
        if (type.equalsIgnoreCase("A/c")) {
            return "Air Conditioned Bus with recliner seats";
        } else if (type.equalsIgnoreCase("Non A/c")) {
            return "Non Air Conditioned Bus";
        } else if (type.equalsIgnoreCase("Sleeper")) {
            return "Sleeper Bus with berth facilities";
        } else {
            return "Standard Bus";
        }
    }
}

class Train implements Fare {
    private String type;
    private double farePerKm;
    private double distance;

    public Train(String type, double farePerKm, double distance) {
        this.type = type;
        this.farePerKm = farePerKm;
        this.distance = distance;
    }

    @Override
    public double getFare() {
        return farePerKm * distance;
    }

    @Override
    public String getAmenities() {
        // Assuming amenities based on the type of train
        if (type.equalsIgnoreCase("General")) {
            return "General class seating";
        } else if (type.equalsIgnoreCase("Sleeper")) {
            return "Sleeper class with berths";
        } else if (type.equalsIgnoreCase("A/c")) {
            return "Air Conditioned compartments";
        } else {
            return "Standard Train";
        }
    }
}

class Flight implements Fare {
    private String type;
    private double farePerKm;
    private double distance;

    public Flight(String type, double farePerKm, double distance) {
        this.type = type;
        this.farePerKm = farePerKm;
        this.distance = distance;
    }

    @Override
    public double getFare() {
        return farePerKm * distance;
    }

    @Override
    public String getAmenities() {
        // Assuming amenities based on the type of flight
        if (type.equalsIgnoreCase("Economy")) {
            return "Economy class seating";
        } else if (type.equalsIgnoreCase("Business")) {
            return "Business class with luxury facilities";
        } else {
            return "Standard Flight";
        }
    }
}

public class M5Q4 {
    public static void main(String[] args) {
        Bus bus = new Bus("A/c", 10, 200); // Assuming A/c bus, fare: $10 per km, distance: 200 km
        Train train = new Train("Sleeper", 5, 300); // Assuming Sleeper class, fare: $5 per km, distance: 300 km
        Flight flight = new Flight("Economy", 15, 500); // Assuming Economy class, fare: $15 per km, distance: 500 km

        System.out.println("Bus Fare: $" + bus.getFare());
        System.out.println("Bus Amenities: " + bus.getAmenities());

        System.out.println("Train Fare: $" + train.getFare());
        System.out.println("Train Amenities: " + train.getAmenities());

        System.out.println("Flight Fare: $" + flight.getFare());
        System.out.println("Flight Amenities: " + flight.getAmenities());
    }
}
