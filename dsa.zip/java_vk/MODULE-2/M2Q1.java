import java.lang.*;

class circle
{
    int radius;

	circle(int r){
     radius=r;
    }
	
    void area(){
		
	   double a=Math.PI * radius * radius;
       System.out.println("Area of circle is "+a);
    }    
		
	 void perimeter(){
		
	   double p=2 * Math.PI * radius;
       System.out.println("Perimeter of circle is "+p);
    }    
	
}

class M2Q1{

  public static void main(String vk[])
 {
	circle c=new circle(5);
    c.area();
    c.perimeter();
  }
}