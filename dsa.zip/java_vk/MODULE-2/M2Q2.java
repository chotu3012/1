import java.lang.*;

class Lamp{
	boolean isOn;
	String LampType; 
	
    Lamp(boolean isOn, String LampType){
        this.isOn=isOn;
		this.LampType=LampType;
    }

    void turnOn()
	{
	 isOn=true;
     System.out.println(LampType+ " Lamp is turned On ");      
     }

     void turnOff()
	{
      isOn=false;
      System.out.println(LampType+ " Lamp is turned Off ");      
     }
} 

class M2Q2{
  public static void main(String vk[])
  {
	Lamp led=new Lamp(false,"LED");
    Lamp halogen=new Lamp(true,"Halogen");	
	
	led.turnOn();
	led.turnOff();
	
	halogen.turnOff();
	halogen.turnOn();
	
  }
}