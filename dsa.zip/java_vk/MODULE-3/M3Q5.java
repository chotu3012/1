import java.lang.*;
import java.util.*;

class  M3Q5
{
	public static void main(String vk[])
	{
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the string");
		String s=sc.nextLine();
		String vow="";
		String con="";
		int v_count=0;
		int c_count=0;
		for(int i=0;i<s.length();i++)
		{
			char ch=s.charAt(i);
			if(ch=='a' ||ch=='e' || ch=='i' ||ch =='o' ||ch=='u' ) 
			{
				vow+=ch;
				v_count++;
			}
			else
			{
				con+=ch;
				c_count++;
			}
		}
		System.out.println("The number of vowels in the given string is "+v_count+" they are");
		for(int i=0;i<vow.length();i++){
			char c=vow.charAt(i);
			System.out.print(c+" ");
		}
		
		System.out.println("\nThe number of consonants in the given string is "+c_count+" they are");
		for(int i=0;i<con.length();i++){
			char c=con.charAt(i);
			System.out.print(c+" ");
		}

	}
}