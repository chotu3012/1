import java.lang.*;
import java.util.*;


class M3Q8
{
	public static void main(String vk[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the main string ");
		String s=sc.nextLine();
		System.out.println("Enter the substring string ");
		String sub=sc.nextLine();
		usingSubstring(s,sub);
		usingStartsEnds(s,sub);
		
	}
	public static void usingSubstring(String s,String sub)
	{
		if(s.contains(sub)){
			int ind=s.indexOf(sub);
			System.out.println("The sub string found at index "+ind);
		}
		else
			System.out.println("String not found");
	}
	
	public static void usingStartsEnds(String s,String sub)
	{
		if(s.startsWith(sub))
		{
			System.out.println("string found. Main string "+s+" starts with substring "+sub);
		}
		else if(s.endsWith(sub))
		{
			System.out.println("string found. Main string "+s+" ends with substring "+sub);
		}
		else
			System.out.println("String not found");
	}
	
	
	
	
}