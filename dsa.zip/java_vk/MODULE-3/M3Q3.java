import java.lang.*;
import java.util.*;
class M3Q3{
		public static void main(String vk[]){
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter the string");
			String s1=sc.nextLine();
			
			System.out.println("Enter an alphabet");
			String alpha=sc.next();
			
			int ind=s1.indexOf(alpha);
			int c=0;
			while(ind!=-1){
				c++;
				ind=s1.indexOf(alpha,ind+1);
			}
			
			System.out.println("The number of occurance of '"+alpha+"' in "+s1+" is "+c);
			
			
		}
}