import java.lang.*;

abstract class Employee {
abstract double getAmount();
}

class WeeklyEmployee extends Employee {
    private double weeklySalary;
    private int numberOfWeeks;

    public WeeklyEmployee(double weeklySalary, int numberOfWeeks) {
        this.weeklySalary = weeklySalary;
        this.numberOfWeeks = numberOfWeeks;
    }

    @Override
    double getAmount() {
        return weeklySalary * numberOfWeeks;
    }
}

class HourlyEmployee extends Employee {
    private double hourlyRate;
    private int totalHours;

    public HourlyEmployee(double hourlyRate, int totalHours) {
        this.hourlyRate = hourlyRate;
        this.totalHours = totalHours;
    }

   
    double getAmount() {
        return hourlyRate * totalHours;
    }
}

public class M5Q2{
    public static void main(String[] args) {
        WeeklyEmployee weeklyEmployee = new WeeklyEmployee(1000, 4); // Weekly salary of 1000 for 4 weeks
        HourlyEmployee hourlyEmployee = new HourlyEmployee(15, 40); // Hourly rate of 15 for 40 hours

        System.out.println("Amount paid to Weekly Employee: $" + weeklyEmployee.getAmount());
        System.out.println("Amount paid to Hourly Employee: $" + hourlyEmployee.getAmount());
    }
}
