import java.lang.*;

interface Vehicle {
    String getCompany();
    String getModel();
    String getType();
    double getConsumption();
    void displayCompanyAndModel();
    double calculateFuelConsumed(double distance);
}

class FourWheeler implements Vehicle {
    private String company;
    private String model;
    private String type;

    public FourWheeler(String company, String model, String type) {
        this.company = company;
        this.model = model;
        this.type = type;
    }

    @Override
    public String getCompany() {
        return company;
    }

    @Override
    public String getModel() {
        return model;
    }

    @Override
    public String getType() {
        return type;
    }

    @Override
    public double getConsumption() {
        if (type.equalsIgnoreCase("Petrol")) {
            return 14; // 14 km/l for petrol 4-wheeler
        } else if (type.equalsIgnoreCase("Diesel")) {
            return 22; // 22 km/l for diesel 4-wheeler
        } else if (type.equalsIgnoreCase("CNG")) {
            return 18; // 18 km/kg for CNG 4-wheeler
        }
        return 0;
    }

    @Override
    public void displayCompanyAndModel() {
        System.out.println("Company: " + company);
        System.out.println("Model: " + model);
    }

    @Override
    public double calculateFuelConsumed(double distance) {
        return distance / getConsumption();
    }
}

class TwoWheeler implements Vehicle {
    private String company;
    private String model;
    private String type;

    public TwoWheeler(String company, String model, String type) {
        this.company = company;
        this.model = model;
        this.type = type;
    }

    @Override
    public String getCompany() {
        return company;
    }

    @Override
    public String getModel() {
        return model;
    }

    @Override
    public String getType() {
        return type;
    }

    @Override
    public double getConsumption() {
        if (type.equalsIgnoreCase("Petrol")) {
            return 62; // 62 km/l for petrol 2-wheeler
        } else if (type.equalsIgnoreCase("Diesel")) {
            return 82; // 82 km/l for diesel 2-wheeler
        } else if (type.equalsIgnoreCase("CNG")) {
            return 72; // 72 km/kg for CNG 2-wheeler
        }
        return 0;
    }

    @Override
    public void displayCompanyAndModel() {
        System.out.println("Company: " + company);
        System.out.println("Model: " + model);
    }

    @Override
    public double calculateFuelConsumed(double distance) {
        return distance / getConsumption();
    }
}

public class M5Q3{
    public static void main(String[] args) {
        FourWheeler car = new FourWheeler("Toyota", "Corolla", "Petrol");
        TwoWheeler bike = new TwoWheeler("Honda", "Activa", "CNG");

        car.displayCompanyAndModel();
        System.out.println("Type: " + car.getType());
        System.out.println("Fuel consumed for 100 km: " + car.calculateFuelConsumed(100) + " liters");

        System.out.println();

        bike.displayCompanyAndModel();
        System.out.println("Type: " + bike.getType());
        System.out.println("Fuel consumed for 100 km: " + bike.calculateFuelConsumed(100) + " liters");
    }
}
