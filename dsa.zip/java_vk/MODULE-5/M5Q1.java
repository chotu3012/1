import java.lang.*;
abstract class Shape {
    abstract double getArea();
    abstract double getVolume();
}

class Square extends Shape {
	
    private double side;
    
    public Square(double side) {
        this.side = side;
    }

    @Override
    double getArea() {
        return side * side;
    }

    @Override
    double getVolume() {
        return 0; // A square is a 2D shape, so it doesn't have volume
    }
}

class Circle extends Shape {
    private double radius;
    private final double PI = 3.14159;

    public Circle(double radius) {
        this.radius = radius;
    }

    @Override
    double getArea() {
        return PI * radius * radius;
    }

    @Override
    double getVolume() {
        return 0; // A circle is a 2D shape, so it doesn't have volume
    }
}

class Cube extends Shape {
    private double side;

    public Cube(double side) {
        this.side = side;
    }

    @Override
    double getArea() {
        return 6 * side * side;
    }

    @Override
    double getVolume() {
        return side * side * side;
    }
}

class Sphere extends Shape {
    private double radius;
    private final double PI = 3.14159;

    public Sphere(double radius) {
        this.radius = radius;
    }

    @Override
    double getArea() {
        return 4 * PI * radius * radius;
    }

    @Override
    double getVolume() {
        return (4.0 / 3.0) * PI * radius * radius * radius;
    }
}

public class M5Q1{
    public static void main(String[] args) {
        Square square = new Square(5);
        Circle circle = new Circle(3);
        Cube cube = new Cube(4);
        Sphere sphere = new Sphere(6);

        System.out.println("Square Area: " + square.getArea());
        System.out.println("Circle Area: " + circle.getArea());
        System.out.println("Cube Area: " + cube.getArea());
        System.out.println("Sphere Area: " + sphere.getArea());

        System.out.println("Cube Volume: " + cube.getVolume());
        System.out.println("Sphere Volume: " + sphere.getVolume());
    }
}
